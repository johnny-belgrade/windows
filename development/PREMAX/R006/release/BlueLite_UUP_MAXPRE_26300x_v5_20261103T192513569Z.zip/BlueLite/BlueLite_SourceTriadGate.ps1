[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$UUPRoot,
 [Parameter(Mandatory=$true)][string]$WindowsQueueFile,
 [string]$LogPath='.\BlueLite_Logs\SourceTriad.log'
)
$ErrorActionPreference='Stop'
function Add-Mapping($Map,[string]$Name,[string]$Hash,[string]$Tag) {
 if([string]::IsNullOrWhiteSpace($Name) -or $Name -ne [IO.Path]::GetFileName($Name)){throw ('Invalid name in {0}: {1}' -f $Tag,$Name)}
 if($Map.ContainsKey($Name)){throw ('Duplicate filename in {0}: {1}' -f $Tag,$Name)}
 $Map.Add($Name,$Hash.ToUpperInvariant())
}
function Compare-Mappings($A,$B,[string]$Tag) {
 if($A.Count -ne $B.Count){throw ('{0} count mismatch: {1}/{2}' -f $Tag,$A.Count,$B.Count)}
 foreach($n in $A.Keys){if(-not $B.ContainsKey($n) -or $A[$n] -ne $B[$n]){throw ('{0} identity mismatch: {1}' -f $Tag,$n)}}
}
try {
 $root=(Resolve-Path -LiteralPath $UUPRoot).Path
 $listFile=Join-Path $root 'List of files UUP.txt'
 $cmdFile=Join-Path $root 'File_renaming_script.cmd'
 $shaFile=Join-Path $root 'SHA-1 checksums file.txt'
 $present=@($listFile,$cmdFile,$shaFile | Where-Object {Test-Path -LiteralPath $_ -PathType Leaf})
 $lDir=Split-Path -Parent $LogPath;if($lDir -and -not(Test-Path -LiteralPath $lDir)){New-Item -ItemType Directory -Path $lDir -Force|Out-Null}
 if($present.Count -eq 0){
  'SOURCE_TRIAD_NOT_PROVIDED; original UUP launcher and Windows D4 queue remain authoritative.'|Set-Content -LiteralPath $LogPath -Encoding UTF8
  Write-Host 'SOURCE_TRIAD_NOT_PROVIDED (optional)' -ForegroundColor Yellow
  exit 0
 }
 if($present.Count -ne 3){throw ('Incomplete source triad: {0}/3 files present' -f $present.Count)}
 $makeMap={New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::OrdinalIgnoreCase)}
 $ledger=& $makeMap; $fromList=& $makeMap; $fromCmd=& $makeMap; $queue=& $makeMap
 foreach($line in [IO.File]::ReadAllLines($shaFile)){
  if($line -match '^([a-fA-F0-9]{40})\s+\*(.+?)\s*$'){Add-Mapping $ledger $Matches[2] $Matches[1] 'sha-ledger'}
 }
 foreach($line in [IO.File]::ReadAllLines($listFile)){
  $f=$line.Split([char]9)
  if($f.Length -ge 4 -and $f[2] -match '^[a-fA-F0-9]{40}$'){Add-Mapping $fromList $f[0].Trim() $f[2] 'uup-file-list'}
 }
 $guidMap=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
 foreach($line in [IO.File]::ReadAllLines($cmdFile)){
  if($line -match '(?i)^\s*rename\s+"([a-f0-9-]{36})"\s+"([^"]+)"\s*$'){
   if($guidMap.ContainsKey($Matches[1])){throw ('Duplicate GUID in rename data: {0}' -f $Matches[1])}
   $guidMap.Add($Matches[1],$Matches[2])
  }
 }
 foreach($name in $guidMap.Values){
  if($fromCmd.ContainsKey($name)){throw ('Duplicate output in rename data: {0}' -f $name)}
  if(-not $ledger.ContainsKey($name)){throw ('Rename-only name: {0}' -f $name)}
  Add-Mapping $fromCmd $name $ledger[$name] 'rename-data'
 }
 $out='';$hash=''
 foreach($line in [IO.File]::ReadAllLines($WindowsQueueFile)){
  if($line -match '^\s*https?://'){
   if($out){if(-not $hash){throw ('Queue hash missing: {0}' -f $out)}; Add-Mapping $queue $out $hash 'windows-queue'}
   $out='';$hash=''
  } elseif($line -match '^\s*out=(.+?)\s*$'){$out=$Matches[1].Trim().Trim('"')}
  elseif($line -match '^\s*checksum=sha-1=([a-fA-F0-9]{40})\s*$'){$hash=$Matches[1]}
 }
 if($out){if(-not $hash){throw ('Queue hash missing: {0}' -f $out)};Add-Mapping $queue $out $hash 'windows-queue'}
 if($ledger.Count -lt 10){throw 'SHA ledger contained too few entries.'}
 Compare-Mappings $ledger $fromList 'list-vs-sha'
 Compare-Mappings $ledger $fromCmd 'rename-vs-sha'
 Compare-Mappings $ledger $queue 'queue-vs-sha'
 $msg=('SOURCE_TRIAD_D4_PASS names={0} GUID={1}' -f $ledger.Count,$guidMap.Count)
 $msg|Set-Content -LiteralPath $LogPath -Encoding UTF8
 Write-Host $msg -ForegroundColor Green
 exit 0
}catch{
 $msg='SOURCE_TRIAD_D4_HOLD: '+$_.Exception.Message
 Write-Host $msg -ForegroundColor Red
 try{$msg|Set-Content -LiteralPath $LogPath -Encoding UTF8}catch{}
 exit 1
}